# # from django import forms
# # from django.contrib.auth.forms import UserCreationForm
# # from django.contrib.auth.models import User

# # class RegisterForm(UserCreationForm):
# #     email = forms.EmailField(required=True)

# #     class Meta:
# #         model = User
# #         fields = ['username', 'email', 'password1', 'password2']


# from django import forms
# from django.contrib.auth import get_user_model

# User = get_user_model()

# class RegisterForm(forms.ModelForm):
#     password = forms.CharField(widget=forms.PasswordInput)
#     confirm_password = forms.CharField(widget=forms.PasswordInput)

#     class Meta:
#         model = User
#         fields = ['username', 'email', 'role', 'password']

#     def clean(self):
#         cleaned_data = super().clean()
#         if cleaned_data.get("password") != cleaned_data.get("confirm_password"):
#             raise forms.ValidationError("Passwords do not match.")
#         return cleaned_data

#     def save(self, commit=True):
#         user = super().save(commit=False)
#         user.set_password(self.cleaned_data["password"])
#         if commit:
#             user.save()
#         return user


from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']